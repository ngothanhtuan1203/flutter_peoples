import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:persons_exam/data/model/repo/model.dart';

import '../../custom_ui/custom_ui.dart';

class WidgetHomePeoples extends StatefulWidget {
  @override
  _WidgetHomePeoplesState createState() => _WidgetHomePeoplesState();
}

class _WidgetHomePeoplesState extends State<WidgetHomePeoples> {
  final aspectRatioBanner = 16 / 9;
  var currentIndex = 0;
  late ScrollController _controller;
  @override
  void initState() {
    _controller = ScrollController()..addListener(_scrollListener);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomePeoplesBloc, HomePeoplesState>(
      builder: (context, state) {
        if (state is HomePeoplesLoaded) {
          return Container(
            child: _buildListView(state),
          );
        } else {
          return Container();
        }
      },
    );
  }
  Widget _buildListView(HomePeoplesLoaded state) {

    var oldsize = MediaQuery.of(context).size;
    final double navigationBarHeight = MediaQuery.of(context).padding.bottom;
    final statusBarHeight = MediaQuery.of(context).viewPadding.top;
    var size = Size(oldsize.width,
        oldsize.height - navigationBarHeight - 70 - statusBarHeight);
    return Container(
      margin: EdgeInsets.only(top: size.height * 0.01),
      width: size.width,
      height: size.height,
      child:
        ListView.builder(
            controller: _controller,
            itemCount: state.peoples.length+1,
            physics: const AlwaysScrollableScrollPhysics(),
            itemBuilder: (context, index) {
              if (index == state.peoples.length) {
                return const Center(child: CircularProgressIndicator());
              }
              People current =
              state.peoples[index];
              return GestureDetector(
                onTap: () => {},
                child: Container(
                  margin: const EdgeInsets.all(8.0),
                  width: size.width,
                  height: size.height * 0.15,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Hero(
                        tag: current.lastName,
                        child: Container(
                          margin: const EdgeInsets.all(8.0),
                          width: size.width * 0.28,
                          decoration: BoxDecoration(
                            borderRadius:
                            BorderRadius.circular(15),
                            image:DecorationImage(
                              image: Image.network(current.image).image,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(
                            left: size.width * 0.02),
                        child: Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: size.height * 0.035,
                            ),
                            AppText(
                              text: "${current.lastName}",
                              size: 17,
                              color: Colors.black,
                              fontWeight: FontWeight.w400,
                            ),
                            SizedBox(
                              height: size.height * 0.005,
                            ),
                            AppText(
                              text: "Email: ${current.email}",
                              size: 14,
                              color:
                              Colors.black.withOpacity(0.5),
                              fontWeight: FontWeight.w300,
                            ),
                            AppText(
                              text:"Age: ${current.age}",
                              size: 14,
                              color:
                              Colors.black.withOpacity(0.5),
                              fontWeight: FontWeight.w300,
                            ),
                            AppText(
                              text: "Phone: ${current.phone}",
                              size: 14,
                              color:
                              Colors.black.withOpacity(0.5),
                              fontWeight: FontWeight.w300,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),

    );
  }
  void _scrollListener() {

    if (_controller.position.atEdge) {
      // Load more items when reaching the end
      bool isBottom = _controller.position.pixels == _controller.position.maxScrollExtent;

      if (isBottom) {
        print('At the bottom');
      } else {
        print('At the top');
        //loadMore
      }
    }
  }
}
